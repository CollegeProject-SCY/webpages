from django.db import models

# Create your models here.

from django.contrib.auth.models import AbstractBaseUser, BaseUserManager

class MyAccountManager(BaseUserManager):
    def create_user(self, email, username, phone, password):
        if not email:
            raise ValueError("Users must have an email address")
        if not username:
            raise ValueError("Users must have an username")
        if not phone:
            raise ValueError("Users must have a contact no")

        user=self.model(
            email=self.normalize_email(email),
            username=username,
            phone=phone,
        )
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self,email,username,phone,password):
        user=self.create_user(
            email=self.normalize_email(email),
            password=password,
            username=username,
            phone=phone,
        )
        user.is_admin=True
        user.is_staff=True
        user.is_superuser=True
        user.save(using=self._db)
        return user


class Account(AbstractBaseUser):
    email=models.EmailField(verbose_name="email",max_length=60,unique=True)
    username=models.CharField(max_length=30,unique=True)
    date_joined=models.DateTimeField(verbose_name='date joined',auto_now_add=True)
    is_admin=models.BooleanField(default=False)
    is_active=models.BooleanField(default=True)
    is_staff=models.BooleanField(default=False)
    is_superuser=models.BooleanField(default=False)
    phone=models.CharField(max_length=10,unique=True)
    

    USERNAME_FIELD='email'
   

    objects=MyAccountManager()

    def __str__(self):
        return self.email+" "+self.password

    def has_perm(self, perm, obj=None):
        return self.is_admin

    def has_module_perms(self, app_label):
        return True

    class Meta:
        db_table='login_account'
        verbose_name='Account List'

class applicants(models.Model):
    #person=models.ForeignKey(Account, on_delete=models.CASCADE)
    admission_no=models.CharField(max_length=50)
    date_of_birth=models.DateTimeField(null=True, blank=True)
    student_name=models.CharField(max_length=30)
    gender=models.CharField(max_length=10)
    father_name=models.CharField(max_length=30)
    mother_name=models.CharField(max_length=30)
    caste=models.CharField(max_length=30)
    rd_number=models.CharField(max_length=10)
    institute_type=models.CharField(max_length=20)
    institute_name=models.CharField(max_length=100)
    institute_address=models.CharField(max_length=255)
    inst_street_address1=models.CharField(max_length=255)
    inst_street_address2=models.CharField(max_length=255)
    inst_city=models.CharField(max_length=20)
    inst_state=models.CharField(max_length=20)
    #inst_postal_code=models.IntegerField()
    student_address=models.CharField(max_length=255)
    stud_street_address1=models.CharField(max_length=255)
    stud_street_address2=models.CharField(max_length=255)
    stud_city=models.CharField(max_length=20)
    stud_state=models.CharField(max_length=20)
    #stud_postal_code=models.IntegerField()
    course=models.CharField(max_length=20)
    year=models.CharField(max_length=10)
    semester=models.CharField(max_length=20)
    adhar_number=models.CharField(max_length=12)
    college_fee_amt=models.CharField(max_length=10)
    from_stop=models.CharField(max_length=50)
    to_stop=models.CharField(max_length=50)
    via_1=models.CharField(max_length=50)
    passport_size_image=models.ImageField(upload_to='photos')
    college_fees_image=models.ImageField(upload_to='photos')
    adhar_image=models.ImageField(upload_to='photos')
    study_certificate_image=models.ImageField(upload_to='photos')
    previous_marks_image=models.ImageField(upload_to='photos')
    terms_cond=models.BooleanField(default=False)
    class Meta:
        db_table='application_db'
        verbose_name='Applicant List'

class contact (models.Model):
    email=models.EmailField(verbose_name="email",max_length=60,unique=True)
    username=models.CharField(max_length=30)
    phone=models.CharField(max_length=10)
    messages=models.CharField(max_length=255)
    class Meta:
        db_table='contact_db'
        verbose_name='Contact List'
    


