from django.contrib.auth.hashers import PBKDF2PasswordHasher
from django.core.mail.message import utf8_charset
from django.http.response import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.http import HttpResponse
from django.utils import timezone

# Create your views here.

from django.views.decorators.csrf import requires_csrf_token
from django.core.mail import send_mail, BadHeaderError
from django.contrib.auth.forms import PasswordResetForm
from django.contrib.auth.hashers import check_password
from django.template.loader import render_to_string
from django.db.models.query_utils import Q
from django.utils.http import urlsafe_base64_encode,urlsafe_base64_decode
from django.contrib.auth.decorators import login_required
from .models import Account,applicants
from typing import cast
from django.utils.encoding import force_bytes, force_str, force_text
from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from django.contrib.auth import login,logout
from django.contrib.auth.tokens import default_token_generator



# Create your views here.

def loged_in(request):
    return render(request,'index.html')

def home(request):
    return render(request,'home.html')
    
@requires_csrf_token
def register(request):
    if request.method =='POST':
         username=request.POST['username']
         email=request.POST['email']
         
         if(Account.objects.filter(username=username).exists()):
            messages.info(request, 'email  exist :(') 
            return redirect('loged_in') 
              
         elif(Account.objects.filter(email=email).exists()):
            messages.info(request, 'email  exist :(') 
            return redirect('loged_in') 
    
    phone=request.POST['phone']
    password1=request.POST['password']
    user_obj =Account.objects.create(username=username, phone=phone, email=email, password=password1)
    user_obj.set_password(password1)
    user_obj.save()
    messages.info(request, 'Account Created Successfully :)')  
    print(' user created '+username) 
    return redirect('loged_in')
            

def log_in(request):  
    if request.method =='POST':
          username=request.POST['username']
          password=request.POST['password']  
          if(Account.objects.filter(username=username).exists()):
                user = Account.objects.get(username=username)
                if user.check_password(password):
                    login(request, user)
                    user.last_login = timezone.now()
                    user.save(update_fields=['last_login'])
                    print('User loged '+username)
                    return HttpResponseRedirect('/')
                else:
                    messages.info(request, 'wrong password')
                    print('wrong password by '+username)
                    return HttpResponseRedirect('loged_in')
          else:
              messages.info(request, 'username not found')
              print('username not found')
              return HttpResponseRedirect('loged_in')

    return render(request,'home')
         
def contact_us(request):
    return render(request,'contact.html')

def about_us(request):
    return render(request,'about.html')

def apply(request):
    return render(request,'apply.html')

def view(request):
    return render(request,'view.html')


def log_out(request):
    logout(request)
    messages.info(request, "Logged out successfully!")
    return redirect('/')
    
def password_reset_request(request):
	if request.method == "POST":
		password_reset_form = PasswordResetForm(request.POST)
		if password_reset_form.is_valid():
			data = password_reset_form.cleaned_data['email']
			associated_users = Account.objects.filter(Q(email=data))
			if associated_users.exists():
				for user in associated_users:
					subject = "Password Reset Requested"
					email_template_name = "password/password_reset_email.txt"
					c = {
					"email":user.email,
					'domain':'127.0.0.1:8000',
					'site_name': 'Website',
					"uid": urlsafe_base64_encode(force_bytes(user.pk)),
					"user": user,
					'token': default_token_generator.make_token(user),
					'protocol': 'http',
					}
					email = render_to_string(email_template_name, c)
					try:
						send_mail(subject, email, 'admin@example.com' , [user.email], fail_silently=False)
					except BadHeaderError:
						return HttpResponse('Invalid header found.')
					return redirect ("/password_reset/done/")
	password_reset_form = PasswordResetForm()
	return render(request=request, template_name="password/password_reset.html", context={"password_reset_form":password_reset_form})
    
#@login_required
#def applyform(request): 
 #   if request.method =='POST':
    #    username=request.POST['username']


  