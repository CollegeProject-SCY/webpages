from django.urls import path
from django.urls.resolvers import URLPattern
from django.contrib.auth import views as auth_views

from . import views



urlpatterns = [
     path('',views.feedback,name="feedback"),
   
]