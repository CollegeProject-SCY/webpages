from django.urls import path
from django.urls.resolvers import URLPattern

from . import views



urlpatterns = [
    path('',views.home,name="home"),
    path('login/',views.login,name="login"),
    path('register',views.register, name="register"),
    path('log_in',views.log_in,name="log_in"),
    path('contact_us/',views.contact_us,name="contact_us"),
    path('about_us/',views.about_us,name="contact_us"),
]