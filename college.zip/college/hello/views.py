from django.http.response import HttpResponse
from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.


from .models import Account
from typing import cast
from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
#from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, UserManager


# Create your views here.
def login(request):
    return render(request,'index.html')

def home(request):
    return render(request,'home.html')

def register(request):
    if request.method =='POST':
         username=request.POST['username']
         phone=request.POST['phone']
         email=request.POST['email']
         password=request.POST['password']
         password1=request.POST['password1']
        
         user_obj =Account.objects.create(username=username, phone=phone, email=email, password=password)
         user_obj.save()
         #request.session['username'] = user.username
         messages.info(request, 'Account Created Successfully :)')  
         print(' user created '+username) 
         return redirect('login')
         
           
    

def log_in(request):  
     if request.method =='POST':
          username=request.POST['username']
          password=request.POST['password']

          if(Account.objects.filter(username=username).exists()):
               if(Account.objects.filter(password=password).exists()):
                    print('you are logged')
                    return redirect('home')
               else:
                    messages.info(request, 'wrong password')
                    print('wrong password')
                    return redirect('login') 
          
          
     user_obj =Account.objects.filter(username=username,password=password)
     if not user_obj:
          messages.info(request, 'username not found')
          print('username not found')
          return redirect('login') 
   
         
def contact_us(request):
    return render(request,'contact.html')
def about_us(request):
    return render(request,'about.html')
   