from django.shortcuts import render

# Create your views here.
from django.shortcuts import render,redirect
from django.http import HttpResponse
from typing import cast
from django.contrib import messages
#from django.contrib.auth import login,authenticate,logout
from .models import FeedBack

# Create your views here.
def feedback(request):
     if request.method =='POST':
         username=request.POST['username']
         email=request.POST['email']
         phone=request.POST['phone']
         message=request.POST['messages']
         data = FeedBack(username=username, email=email, phone=phone, messages=message)
         data.save()
         messages.info(request, 'Thank you for contact us') 
         
          #return render(request, 'base.html')
     return render(request, 'contact.html')






